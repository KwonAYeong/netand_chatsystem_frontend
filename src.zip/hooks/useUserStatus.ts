import { useEffect, useRef, useMemo, useCallback } from 'react';
import {
  subscribeToStatus,
  unsubscribeFromStatus,
  default as client,
} from '../lib/websocket';
import { subscribeWithRetry } from '../lib/websocket';
// ✅ 정확히 연결될 때까지 기다리는 함수
const waitUntilWebSocketReady = (callback: () => void, retry = 0) => {
  if (client.connected) {
    console.log('✅ WebSocket 연결됨 → 콜백 실행');
    callback();
    return;
  }
  if (retry >= 50) {
    console.warn('❌ WebSocket 연결 준비 실패 (타임아웃)');
    return;
  }
  setTimeout(() => waitUntilWebSocketReady(callback, retry + 1), 100);
};

export default function useUserStatus(
  userIds: number[],
  onStatusUpdate: (userId: number, status: 'ONLINE' | 'AWAY') => void
) {
  const subscribedRef = useRef<Set<number>>(new Set());

  const stableUserIds = useMemo(
    () => userIds.filter((id): id is number => typeof id === 'number'),
    [userIds.join(',')] // 👉 문자열로 캐싱하면 비교 쉬움
  );

  const stableOnStatusUpdate = useCallback(onStatusUpdate, []);

  useEffect(() => {
    console.log('🕵️ useUserStatus 실행됨');
    console.log('🕵️ client.connected:', client.connected);
    console.log('🕵️ client 상태:', client);

    const waitUntilWebSocketReady = (callback: () => void, retry = 0) => {
      const isConnected = client.connected;
      const isSocketReady = !!(client as any)._connection;

      if (isConnected && isSocketReady) {
        console.log('✅ [WebSocket] 연결 완전됨 → 콜백 실행');
        callback();
        return;
      }

      if (retry >= 50) {
        console.warn('❌ WebSocket 연결 준비 실패 (타임아웃)');
        return;
      }

      setTimeout(() => waitUntilWebSocketReady(callback, retry + 1), 100);
    };

    waitUntilWebSocketReady(() => {
      stableUserIds.forEach((id) => {
        if (!subscribedRef.current.has(id)) {
          subscribeWithRetry(id, stableOnStatusUpdate);
          subscribedRef.current.add(id);
        }
      });
    });

    return () => {
      stableUserIds.forEach((id) => {
        if (subscribedRef.current.has(id)) {
          unsubscribeFromStatus(id);
          subscribedRef.current.delete(id);
          console.log(`🗑️ 상태 구독 해제: /sub/status/${id}`);
        }
      });
    };
  }, [stableUserIds, stableOnStatusUpdate]);
}
