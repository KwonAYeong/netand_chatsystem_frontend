// src/lib/websocket.ts
import SockJS from 'sockjs-client';
import { Client, IMessage, StompSubscription } from '@stomp/stompjs';

let socket: WebSocket | null = null;

const client = new Client({
  webSocketFactory: () => {
    socket = new SockJS('http://localhost:8080/ws');
    return socket;
  },
  reconnectDelay: 5000,
  heartbeatIncoming: 4000,
  heartbeatOutgoing: 4000,
  debug: (str) => console.debug('[STOMP DEBUG]', str),
});

const subscriptions = new Map<string, StompSubscription>();

export const connectSocket = (onConnected?: () => void) => {
  console.log('🧪 connectSocket() 호출됨');

  if (client.connected || client.active) {
    console.log('⚠️ WebSocket 이미 연결됨 또는 연결 시도 중');
    onConnected?.();
    return;
  }

  client.onConnect = () => {
    console.log('✅ WebSocket 연결 완료 (client.onConnect)');
    onConnected?.();
  };

  client.onStompError = (frame) => {
    console.error('❌ STOMP 에러:', frame);
  };

  client.activate();
};

export const disconnectSocket = () => {
  if (client.connected) {
    subscriptions.forEach((sub) => sub.unsubscribe());
    subscriptions.clear();
    client.deactivate();
    console.log('🔌 WebSocket disconnected');
  }
};

export const sendMessage = (payload: any) => {
  if (!client.connected) {
    console.warn('⚠️ WebSocket 아직 연결 안 됨. 메시지 전송 실패');
    return;
  }

  client.publish({
    destination: '/pub/chat.sendMessage',
    body: JSON.stringify(payload),
  });
};

export const subscribeToRoom = (
  chatRoomId: number,
  onMessage: (msg: any) => void,
  onUnreadIncrease: (roomId: number) => void,
  onUnreadClear: (roomId: number) => void,
  currentChatRoomId: number
) => {
  
  const destination = `/sub/chatroom/${chatRoomId}`;

  if (subscriptions.has(destination)) {
    console.log(`⚠️ Already subscribed to ${destination}`);
    return;
  }
 if (!client.connected || !(client as any)._connection) {
    console.warn(`❌ STOMP 연결 안 됨 — ${destination} 구독 취소`);
    return;
  }
  const sub = client.subscribe(destination, (message: IMessage) => {
    const parsed = JSON.parse(message.body);
    onMessage(parsed);

    if (parsed.chatRoomId === currentChatRoomId) {
      onUnreadClear(parsed.chatRoomId);
    } else {
      onUnreadIncrease(parsed.chatRoomId);
    }
  });

  subscriptions.set(destination, sub);
  console.log(`📥 Subscribed to ${destination}`);
};

export const unsubscribeFromRoom = (chatRoomId: number) => {
  const destination = `/sub/chatroom/${chatRoomId}`;
  const sub = subscriptions.get(destination);

  if (sub) {
    sub.unsubscribe();
    subscriptions.delete(destination);
    console.log(`🗑️ Unsubscribed from ${destination}`);
  }
};
export const waitUntilReady = (callback: () => void, retry = 0) => {
  const isConnected = client.connected;
  const isSocketReady = !!(client as any)._connection;

  if (isConnected && isSocketReady) {
    console.log('✅ WebSocket 완전 연결됨 → 콜백 실행');
    callback();
    return;
  }

  if (retry >= 30) {
    console.warn('❌ WebSocket 연결 준비 대기 시간 초과');
    console.log('🛠 최종 상태:', { isConnected, isSocketReady });
    return;
  }

  console.log(`⏳ WebSocket 연결 대기 중... (재시도 ${retry})`, {
    isConnected,
    isSocketReady,
  });

  setTimeout(() => waitUntilReady(callback, retry + 1), 100);
};

export const subscribeToStatus = (
  userId: number,
  onStatus: (userId: number, status: 'ONLINE' | 'AWAY') => void
) => {
  const destination = `/sub/status/${userId}`;

  if (subscriptions.has(destination)) {
    console.log(`⏩ 이미 구독된 상태: ${destination}`);
    return;
  }

  if (!client.connected || !(client as any)._connection) {
    console.warn(`❌ WebSocket 아직 연결되지 않아 상태 구독 실패: ${destination}`);
    console.log('🔍 client.connected:', client.connected);
  console.log('🔍 client._connection:', (client as any)._connection);
    return;
  }

  console.log(`📡 상태 구독 시작: ${destination}`);

  const sub = client.subscribe(destination, (message: IMessage) => {
    const status = message.body as 'ONLINE' | 'AWAY';
    console.log(`📥 상태 수신됨 [userId=${userId}] → ${status}`);
    onStatus(userId, status);
  });

  subscriptions.set(destination, sub);
  console.log(`✅ 구독 성공: ${destination}`);
};


export const unsubscribeFromStatus = (userId: number) => {
  const destination = `/sub/status/${userId}`;
  const sub = subscriptions.get(destination);
  if (sub) {
    sub.unsubscribe();
    subscriptions.delete(destination);
    console.log(`📴 상태 구독 해제: ${destination}`);
  }
};
export const setOnline = (userId: number) => {
  if (!client.connected) {
    console.warn('⚠️ WebSocket 연결 안 됨 - ONLINE 전송 실패');
    return;
  }
  console.log('📡 setOnline 전송');
  client.publish({
    destination: '/pub/status/online',
    headers: { userId: String(userId) }, // 여기에 userId 헤더 추가
    body: '',
  });
};

export const setAway = (userId: number) => {
  if (!client.connected) {
    console.warn('⚠️ WebSocket 연결 안 됨 - AWAY 전송 실패');
    return;
  }
  console.log('📡 setAway 전송');
  client.publish({
    destination: '/pub/status/away',
    headers: { userId: String(userId) }, // 여기도 userId 헤더 추가
    body: '',
  });
};
export const resetStatusSubscriptions = () => {
  Array.from(subscriptions.keys()).forEach((key) => {
    if (key.startsWith('/sub/status/')) {
      subscriptions.get(key)?.unsubscribe();
      subscriptions.delete(key);
    }
  });
  console.log('♻️ 상태 구독 모두 해제됨');
};
export const resubscribeStatuses = (
  userId: number,  // 현재 로그인된 userId
  targetIds: number[], // 상대방 id들
  onStatus: (id: number, status: 'ONLINE' | 'AWAY') => void
) => {
  resetStatusSubscriptions(); // 먼저 기존 상태 구독 초기화

  targetIds.forEach((id) => {
    if (id !== userId) {
      subscribeToStatus(id, onStatus); // 상대만 구독
    }
  });
};
export const connectAndSubscribeUsers = (
  userIds: number[],
  onStatus: (userId: number, status: 'ONLINE' | 'AWAY') => void
) => {
  const trySubscribe = () => {
    console.log('✅ WebSocket 완전히 연결됨 → 상태 구독 시작');
    userIds.forEach((id) => subscribeToStatus(id, onStatus));
  };

  if (client.connected) {
    waitUntilReady(trySubscribe); // ✅ 함수 정의 이후에 호출해야 함
    return;
  }

  client.onConnect = () => {
    waitUntilReady(trySubscribe); // ✅ 여기도 동일
  };

  client.activate();
};

export const subscribeWithRetry = (
  userId: number,
  onStatus: (userId: number, status: 'ONLINE' | 'AWAY') => void,
  retry = 0
) => {
  const isConnected = client.connected;
  const isSocketReady = !!(client as any)._connection;

  if (isConnected && isSocketReady) {
    subscribeToStatus(userId, onStatus);
    console.log(`✅ 구독 성공: /sub/status/${userId}`);
  } else {
    if (retry >= 50) {
      console.error(`❌ 구독 재시도 실패: /sub/status/${userId}`);
      return;
    }

    console.log(`⏳ 구독 대기: /sub/status/${userId} (retry ${retry})`);
    setTimeout(() => subscribeWithRetry(userId, onStatus, retry + 1), 100);
  }
};

export default client;
