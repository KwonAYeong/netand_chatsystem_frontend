const FilePreview = () => <div>FilePreview</div>; export default FilePreview;
