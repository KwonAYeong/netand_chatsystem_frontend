const EmojiPicker = () => <div>EmojiPicker</div>; export default EmojiPicker;
