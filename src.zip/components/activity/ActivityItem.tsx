const ActivityItem = () => <div>ActivityItem</div>; export default ActivityItem;
