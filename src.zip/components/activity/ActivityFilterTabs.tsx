const ActivityFilterTabs = () => <div>ActivityFilterTabs</div>; export default ActivityFilterTabs;
