const ActivityMenu = () => <div>ActivityMenu</div>; export default ActivityMenu;
