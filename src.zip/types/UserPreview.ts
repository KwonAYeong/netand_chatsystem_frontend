export type User = {
  userId: number;
  name: string;
  profileImageUrl: string;
};
