declare module 'sockjs-client' {
  const SockJS: any;
  export default SockJS;
}
