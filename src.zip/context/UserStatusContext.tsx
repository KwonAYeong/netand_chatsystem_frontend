import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
  useRef,
} from 'react';
import {
  subscribeToStatus,
  subscribeWithRetry,
  unsubscribeFromStatus,
} from '../lib/websocket';
import { useUser } from './UserContext';

interface UserStatusMap {
  [userId: number]: 'ONLINE' | 'AWAY';
}

interface UserStatusContextValue {
  userStatuses: Record<number, 'ONLINE' | 'AWAY'>;
  setUserStatuses: React.Dispatch<
    React.SetStateAction<Record<number, 'ONLINE' | 'AWAY'>>
  >;
  subscribeUsers: (userIds: number[]) => void;
  unsubscribeUsers: (userIds: number[]) => void;
}

const UserStatusContext = createContext<UserStatusContextValue>({
  userStatuses: {},
  setUserStatuses: () => {}, // ✅ 추가됨
  subscribeUsers: () => {},
  unsubscribeUsers: () => {},
});

export const UserStatusProvider = ({ children }: { children: ReactNode }) => {
  const [userStatuses, setUserStatuses] = useState<
    Record<number, 'ONLINE' | 'AWAY'>
  >({});
  const subscribedUsersRef = useRef<Set<number>>(new Set());
  const { user } = useUser(); // ✅ 현재 로그인한 유저 정보
  const myUserId = user?.userId;

  const onStatus = (userId: number, status: 'ONLINE' | 'AWAY') => {
    setUserStatuses((prev) => ({ ...prev, [userId]: status }));
  };

  const subscribeUsers = (userIds: number[]) => {
    userIds.forEach((id) => {
      if (id === myUserId) return; // ⛔ 자기 자신은 구독하지 마!
      if (!subscribedUsersRef.current.has(id)) {
        subscribeWithRetry(id, onStatus);
        subscribedUsersRef.current.add(id);
      }
    });
  };

  const unsubscribeUsers = (userIds: number[]) => {
    userIds.forEach((id) => {
      if (subscribedUsersRef.current.has(id)) {
        unsubscribeFromStatus(id);
        subscribedUsersRef.current.delete(id);
        setUserStatuses((prev) => {
          const copy = { ...prev };
          delete copy[id];
          return copy;
        });
      }
    });
  };

  return (
    <UserStatusContext.Provider
      value={{
        userStatuses,
        setUserStatuses, // ✅ 여기 추가됨
        subscribeUsers,
        unsubscribeUsers,
      }}
    >
      {children}
    </UserStatusContext.Provider>
  );
};

export const useUserStatusContext = () => useContext(UserStatusContext);
