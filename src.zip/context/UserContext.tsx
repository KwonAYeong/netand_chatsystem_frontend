import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { getUserProfileById } from '../api/profile';
import type { User } from '../types/user';
import client, { connectSocket, setOnline } from '../lib/websocket';
import type { Dispatch, SetStateAction } from 'react';

interface UserContextValue {
  user: User | null;
  setUser: Dispatch<SetStateAction<User | null>>;
  setUserById: (id: number, onReady?: () => void) => void
  wsConnected: boolean;
}

const UserContext = createContext<UserContextValue>({
  user: null,
  setUser: () => {},
  setUserById: () => {},
  wsConnected: false,
});

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [wsConnected, setWsConnected] = useState(false);

  const setUserById = async (id: number, onReady?: () => void) => {
    try {
      const data = await getUserProfileById(id);
      const formattedUser: User = {
        userId: data.id,
        name: data.name,
        email: data.email,
        company: data.company,
        position: data.position,
        profileImageUrl: data.profileImageUrl,
        isActive: data.active,
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
        nickname: data.nickname,
        status: 'AWAY',
      };
      setUser(formattedUser);
      onReady?.();
    } catch (err) {
      console.error('❌ 유저 정보 불러오기 실패', err);
    }
  };

  // WebSocket 연결 시도 및 상태 추적
useEffect(() => {
  const interval = setInterval(() => {
    const isConnected = client.connected && !!(client as any)._connection;
    if (isConnected) {
      setWsConnected(true);
      clearInterval(interval);
    }
  }, 200);
  return () => clearInterval(interval);
}, []);

  // WebSocket 연결 후, user.isActive가 true일 때만 setOnline 호출
  useEffect(() => {
    if (user?.isActive && wsConnected) {
      setOnline(user.userId);
      console.log('웹 접속 자동으로 ONLINE 상태 전송');
    }
  }, [user?.isActive, wsConnected]);

  useEffect(() => {
    setUserById(1); // 자동 로그인용
  }, []);

  return (
    <UserContext.Provider
      value={{ user, setUser, setUserById, wsConnected }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser(): UserContextValue {
  return useContext(UserContext);
}
